#pragma once
#define GIT_COMMIT_HASH    "e5baf65c0fe04e70ff4a227034c41484e574bd26"
#define GIT_BRANCH         ""
#define GIT_COMMIT_MESSAGE "    윈도우처럼: 끄는 중 Esc 로 취소, 제목줄 오른쪽 클릭 창 메뉴, 모달 대화상자가 있으면 부모를 누를 때 대화상자로"
#define GIT_COMMIT_DATE    "Sat Oct 3 14:43:22 2026"
#define GIT_DIRTY          ""
#define GIT_TAG            "v0.50.1-44-ge5baf65c"
#define GIT_COMMITS        "6335"
