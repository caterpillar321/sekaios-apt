#pragma once
#define GIT_COMMIT_HASH    "32e3cf3a2e5ea4ceed8a0abd8c84ef17adb1f770"
#define GIT_BRANCH         ""
#define GIT_COMMIT_MESSAGE "    Cursor: an output whose hardware cursor fails 3 times in a row stays on software cursors — a secondary GPU that can't take the cursor buffer retried, failed and logged on every cursor move (557 times in one login)"
#define GIT_COMMIT_DATE    "Thu Oct 8 14:30:47 2026"
#define GIT_DIRTY          ""
#define GIT_TAG            "v0.50.1-68-g32e3cf3a"
#define GIT_COMMITS        "6359"
