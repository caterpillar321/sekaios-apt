#pragma once
#define GIT_COMMIT_HASH    "46dce59cad0b6d516bf513fa5369457c797eb43a"
#define GIT_BRANCH         ""
#define GIT_COMMIT_MESSAGE "    kde-server-decoration: don't answer request_mode (like upstream) — answering every request with server made GTK3 headerbar windows re-request client forever (~36k round trips/s, app and compositor busy at idle)"
#define GIT_COMMIT_DATE    "Sun Oct 18 11:37:38 2026"
#define GIT_DIRTY          ""
#define GIT_TAG            "v0.50.1-70-g46dce59c"
#define GIT_COMMITS        "6361"
