#pragma once
#define GIT_COMMIT_HASH    "22f8501e56d9cc6a6ee829949d0f00f85abea78b"
#define GIT_BRANCH         ""
#define GIT_COMMIT_MESSAGE "    SEKAI_BORDER_CORNER: no outer pull-in for 2px+ borders — the real cause (window/bar radius -1/-2) is fixed, the pull-in only made the corner border ~12% thinner"
#define GIT_COMMIT_DATE    "Sat Nov 21 13:49:40 2026"
#define GIT_DIRTY          ""
#define GIT_TAG            "v0.50.1-95-g22f8501e"
#define GIT_COMMITS        "6386"
