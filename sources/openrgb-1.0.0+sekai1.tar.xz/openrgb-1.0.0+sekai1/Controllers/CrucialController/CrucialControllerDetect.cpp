/*---------------------------------------------------------*\
| CrucialControllerDetect.cpp                               |
|                                                           |
|   Detector for Crucial Ballistix RAM                      |
|                                                           |
|   Adam Honse (CalcProgrammer1)                19 Jan 2020 |
|                                                           |
|   This file is part of the OpenRGB project                |
|   SPDX-License-Identifier: GPL-2.0-or-later               |
\*---------------------------------------------------------*/

#include <stdio.h>
#include <vector>
#include "DetectionManager.h"
#include "CrucialController.h"
#include "LogManager.h"
#include "RGBController_Crucial.h"
#include "i2c_smbus.h"
#include "pci_ids.h"

using namespace std::chrono_literals;

/*---------------------------------------------------------*\
| This list contains the available SMBus addresses for      |
| Crucial RAM                                               |
\*---------------------------------------------------------*/
#define CRUCIAL_ADDRESS_COUNT  8

static const unsigned char crucial_addresses[] =
{
    0x39,
    0x3A,
    0x3B,
    0x3C,
    0x20,
    0x21,
    0x22,
    0x23
};

#define CRUCIAL_CONTROLLER_NAME "Crucial DRAM"
std::string concatHexArray(const unsigned char array[], int count, const char split_char[])
{
    std::string addresses = "";
    for(int i = 0; i < count; i++)
    {
        char buffer[6];
        snprintf(buffer, 6, "0x%02X%s", array[i], (i < count-1)? split_char: "");
        addresses += buffer;
    }
    return addresses;
}
#define TESTING_ADDRESSES concatHexArray(crucial_addresses, CRUCIAL_ADDRESS_COUNT, "|").c_str()

unsigned char CrucialRegisterRead(i2c_smbus_interface* bus, crucial_dev_id dev, crucial_register reg)
{
    //Write Aura register
    bus->i2c_smbus_write_word_data(dev, 0x00, ((reg << 8) & 0xFF00) | ((reg >> 8) & 0x00FF));

    //Read Aura value
    return(bus->i2c_smbus_read_byte_data(dev, 0x81));
}

bool TestForCrucialController(i2c_smbus_interface* bus, unsigned char address)
{
    bool pass = false;

    int res = bus->i2c_smbus_read_byte(address);

    if(res >= 0)
    {
        pass = true;

        LOG_DEBUG("[%s] Detected an I2C device at address %02X", CRUCIAL_CONTROLLER_NAME, address);

        for(int i = 0xA0; i < 0xB0; i++)
        {
            res = bus->i2c_smbus_read_byte_data(address, i);

            if(res != (i - 0xA0))
            {
                LOG_VERBOSE("[%s] Detection failed testing register %02X.  Expected %02X, got %02X.", CRUCIAL_CONTROLLER_NAME, i, (i - 0xA0), res);

                pass = false;
            }
        }

        if(pass)
        {
            LOG_DEBUG("[%s] Checking for Micron string", CRUCIAL_CONTROLLER_NAME);

            char buf[16];
            for(int i = 0; i < 16; i++)
            {
                buf[i] = CrucialRegisterRead(bus, address, CRUCIAL_REG_MICRON_CHECK_1 + i);
            }

            if(strcmp(buf, "Micron") == 0)
            {
                LOG_DEBUG("[%s] Device %02X is a Micron device, continuing", CRUCIAL_CONTROLLER_NAME, address);
            }
            else
            {
                for(int i = 0; i < 16; i++)
                {
                    buf[i] = CrucialRegisterRead(bus, address, CRUCIAL_REG_MICRON_CHECK_2 + i);
                }

                if(strcmp(buf, "Micron") == 0)
                {
                    LOG_DEBUG("[%s] Device %02X is a Micron device, continuing", CRUCIAL_CONTROLLER_NAME, address);
                }
                else
                {
                    LOG_DEBUG("[%s] Device %02X is not a Micron device, skipping", CRUCIAL_CONTROLLER_NAME, address);
                    pass = false;
                }
            }
        }
    }

    return(pass);
}

void CrucialRegisterWrite(i2c_smbus_interface* bus, unsigned char dev, unsigned short reg, unsigned char val)
{
    //Write Crucial register
    bus->i2c_smbus_write_word_data(dev, 0x00, ((reg << 8) & 0xFF00) | ((reg >> 8) & 0x00FF));

    //Write Crucial value
    bus->i2c_smbus_write_byte_data(dev, 0x01, val);
}

DetectedControllers DetectCrucialControllers(std::vector<i2c_smbus_interface*> &buses)
{
    DetectedControllers detected_controllers;

    for(unsigned int bus = 0; bus < buses.size(); bus++)
    {
        int address_list_idx = -1;

        IF_DRAM_SMBUS(buses[bus]->info.pci_vendor, buses[bus]->info.pci_device)
        {
            for(unsigned int slot = 0; slot < 4; slot++)
            {
                int res = buses[bus]->i2c_smbus_read_byte(0x27);

                if(res < 0)
                {
                    break;
                }

                LOG_DEBUG("[%s] Remapping RAM module on 0x27", CRUCIAL_CONTROLLER_NAME);
                do
                {
                    address_list_idx++;

                    if(address_list_idx < CRUCIAL_ADDRESS_COUNT)
                    {
                        res = buses[bus]->i2c_smbus_read_byte(crucial_addresses[address_list_idx]);
                    }
                    else
                    {
                        break;
                    }
                } while(res >= 0);

                if(address_list_idx < CRUCIAL_ADDRESS_COUNT)
                {
                    LOG_DEBUG("[%s] Remapping slot %d to address %02X", CRUCIAL_CONTROLLER_NAME, slot, crucial_addresses[address_list_idx]);
                    CrucialRegisterWrite(buses[bus], 0x27, 0x82EE, slot);
                    CrucialRegisterWrite(buses[bus], 0x27, 0x82EF, (crucial_addresses[address_list_idx] << 1));
                    CrucialRegisterWrite(buses[bus], 0x27, 0x82F0, 0xF0);
                }

                std::this_thread::sleep_for(1ms);
            }

            LOG_DEBUG("[%s] In bus: %02X:%02X looking for devices at [%s]", CRUCIAL_CONTROLLER_NAME, buses[bus]->info.pci_vendor, buses[bus]->info.pci_device, TESTING_ADDRESSES);

            // Add Crucial controllers
            for(unsigned int address_list_idx = 0; address_list_idx < CRUCIAL_ADDRESS_COUNT; address_list_idx++)
            {
                LOG_DEBUG("[%s] Testing address %02X to see if there is a device there", CRUCIAL_CONTROLLER_NAME, crucial_addresses[address_list_idx]);

                if(TestForCrucialController(buses[bus], crucial_addresses[address_list_idx]))
                {
                    CrucialController*     controller     = new CrucialController(buses[bus], crucial_addresses[address_list_idx]);
                    RGBController_Crucial* rgb_controller = new RGBController_Crucial(controller);

                    detected_controllers.push_back(rgb_controller);
                }

                std::this_thread::sleep_for(1ms);
            }
        }
    }

    return(detected_controllers);
}

REGISTER_I2C_DETECTOR("Crucial Ballistix", DetectCrucialControllers);
